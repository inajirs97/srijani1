package com.deloitte.grocery.dao;

import java.sql.*;
import java.util.ArrayList;

import com.deloitte.grocery.model.UserDetails;

public class UserDAO {
	public static Connection connectToDB() {
		Connection connection = null;
		try {
			// Step 1 Register to driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// Step 2 Create Connection
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return connection;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	
	
	
	public static void addUser(UserDetails user) {

		try { // Step 3 create the Statement
			Connection con = connectToDB();
			PreparedStatement stmt = con.prepareStatement("insert into user_tbl values (?,?,?,?,?,?)");
			stmt.setInt(1, user.getUserId());
			stmt.setString(2, user.getName());
			stmt.setString(3, user.getEmail());
			stmt.setString(4, user.getPhNo());
			stmt.setString(5, user.getUserName());
			stmt.setString(6, user.getPass());
			int affectedRows = stmt.executeUpdate();
			System.out.println("Affected Rows=" + affectedRows);
			// CLose the connection
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
	
	
	public static ArrayList<UserDetails> displayuser() {
		ArrayList<UserDetails> table = new ArrayList<UserDetails>();

		try { // Step 3 create the Statement
			Connection con = connectToDB();
			PreparedStatement stmt = connectToDB().prepareStatement("Select * from user_tbl");

			ResultSet rs = stmt.executeQuery();
			if(!rs.next())
				System.out.println("No Data");
			while (rs.next()) {
				UserDetails x = new UserDetails();
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String email = rs.getString(3);
				String phNo = rs.getString(4);
				String userName = rs.getString(5);
				String pass = rs.getString(6);
				x.setUserId(id);
				x.setName(name);
				x.setEmail(email);
				x.setPhNo(phNo);
				x.setUserName(userName);
				x.setPass(pass);
				table.add(x);

			}

			// CLose the connection
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return table;
	}

	
	
	
	
	public static boolean login(String userName, String pass) {
		boolean flag=false;

		try { // Step 3 create the Statement
			Connection con = connectToDB();
			PreparedStatement stmt = connectToDB().prepareStatement("Select count(*) from user_tbl where userName=? AND pass=?");
			stmt.setString(1,userName);
			stmt.setString(2,pass);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				flag = true;
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return flag;
	}
}
