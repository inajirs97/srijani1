package com.deloitte.grocery.services;

import java.util.ArrayList;

import com.deloitte.grocery.model.UserDetails;

public interface ServiceInterface {

	public void addUser(int userId, String name, String email, String userName, String phNo, String pass);
	public ArrayList<UserDetails> displayUser();
	public boolean loginUser(String email,String pass);
	
}
